﻿using System;

namespace Core.PacticeConsoleApp
{
    class Program
    {
        //static void Main(string[] args)
        //{
        //    Console.WriteLine("Hello World!");
        //}
    }
}
