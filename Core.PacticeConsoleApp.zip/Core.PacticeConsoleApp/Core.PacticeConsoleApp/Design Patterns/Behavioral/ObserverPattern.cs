﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Core.PacticeConsoleApp.Design_Patterns.Behavioral
{
    public class ObserverPattern
    {
        //static void Main(string[] args)
        //{
           

        //    // The Client Code
        //    var subject = new Subject();
        //    var observerA = new ConcreateObserverA();
        //    subject.Attach(observerA);

        //    var observerB = new ConcreateObserverB();
        //    subject.Attach(observerB);

        //    subject.SomeBusinessLogic();
        //    subject.SomeBusinessLogic();
        //    subject.Detach(observerB);
        //    subject.SomeBusinessLogic();
        //    Console.ReadKey();
        //}
    }

    public interface IObserver
    {
        // Receive Update from subject
        void Update(ISubject subject);
    }
    public interface ISubject
    {
        // Attach an observer to the subject.
        void Attach(IObserver observer);

        // Detach an objserver from the subject
        void Detach(IObserver observer);

        //  Notify all observer about an avent
        void Notify();
    }

    public class Subject : ISubject
    {
        public int State { get; set; } = -0;

        private List<IObserver> _observers = new List<IObserver>();
        public void Attach(IObserver observer) {
            Console.WriteLine("Subject: Attached an observer...{0}", observer.GetType().Name);
            this._observers.Add(observer);
        }

        public void Detach(IObserver observer) {
            Console.WriteLine("Subject: Detached an observer....{0}", observer.GetType().Name);
            this._observers.Remove(observer);
        }

        // Trigger an update in each subscriber.
        public void Notify() {
            
           foreach(var observer in _observers)
            {
                observer.Update(this);
                Console.WriteLine("Subject: Notifying observers...{0}", observer.GetType().Name);
            }
        }

        
        public void SomeBusinessLogic()
        {
            Console.WriteLine("\nSubject : I'm doing something important");
            this.State = new Random().Next(0, 10);
            Thread.Sleep(1500);

            Console.WriteLine("Subject: My state has just changed to: " + this.State);
            this.Notify();
        }
    }

    class ConcreateObserverA : IObserver
    {
        public void Update(ISubject subject)
        {
            if((subject as Subject).State < 3)
            {
                Console.WriteLine("ConcreteObserverA: Reacted to the event.");
            }
        }
    }

    class ConcreateObserverB : IObserver
    {
        public void Update(ISubject subject)
        {
            if ((subject as Subject).State == 0 || (subject as Subject).State >= 2)
            {
                Console.WriteLine("ConcreateObserverB: Reacted to the event.");
            }
        }
    }
}
