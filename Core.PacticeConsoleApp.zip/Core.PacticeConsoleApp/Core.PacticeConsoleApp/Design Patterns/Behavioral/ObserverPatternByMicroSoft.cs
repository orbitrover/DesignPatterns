﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.PacticeConsoleApp.Design_Patterns.Behavioral
{
    /// <summary>
    /// The observer design pattern is suitable for distributed push-based notifications, 
    /// because it supports a clean separation between two different components or application layers, 
    /// such as a data source (business logic) layer and a user interface (display) layer. 
    /// The pattern can be implemented whenever a provider uses callbacks to supply its clients with current information.
    /// </summary>
    public class ObserverPatternByMicroSoft
    {
        static void Main(string[] args)
        {

        }
    }

    public class BaggageInfo
    {
        private int flightNo;
        private string origin;
        private int location;

        internal BaggageInfo(int flight, string from,int carousel)
        {
            this.flightNo = flight;
            this.origin = from;
            this.location = carousel;
        }
        public int FlightNumber
        {
            get { return this.flightNo; }
        }

        public string From { get { return this.origin; } }
        public int Carousel { get { return this.location; } }
    }

    public class BaggageHandler : IObservable<BaggageInfo>
    {
        private List<IObserver<BaggageInfo>> observers;
        private List<BaggageInfo> flights;
        public BaggageHandler()
        {
            observers = new List<IObserver<BaggageInfo>>();
            flights = new List<BaggageInfo>();
        }
        public IDisposable Subscribe(IObserver<BaggageInfo> observer)
        {
            if (!observers.Contains(observer))
            {
                observers.Add(observer);
                foreach (var item in flights)
                    observer.OnNext(item);
            }
            return new Unsubscriber<BaggageInfo>(observers, observer);
        }

        public void BaggageStatus(int flightNo)
        {
            BaggageStatus(flightNo, String.Empty, 0);
        }
        /// <summary>
        /// Called to indicate all baggage is now unloaded.
        /// </summary>
        /// <param name="flightNo"></param>
        /// <param name="from"></param>
        /// <param name="carousel"></param>
        public void BaggageStatus(int flightNo, string from, int carousel)
        {
            var info = new BaggageInfo(flightNo, from, carousel);
            // Carousel is assigned, so add new info object to list.
            if(carousel > 0 && !flights.Contains(info))
            {
                flights.Add(info);
                foreach (var observer in observers)
                    observer.OnNext(info);
            }
            else if(carousel == 0)
            {
                var flightsToRemove = new List<BaggageInfo>();
                foreach(var flight in flights)
                {
                    if(info.FlightNumber == flight.FlightNumber)
                    {
                        flightsToRemove.Add(flight);
                        foreach (var observer in observers)
                            observer.OnNext(info);
                    }
                }
                foreach(var flightToRemove in flightsToRemove)
                {
                    flights.Remove(flightToRemove);
                }
                flightsToRemove.Clear();
            }
        }

        public void LastBaggageClaimed()
        {
            foreach (var observer in observers)
                observer.OnCompleted();
            observers.Clear();
        }
    }

    internal class Unsubscriber<BaggageInfo> : IDisposable
    {
        private List<IObserver<BaggageInfo>> _observers;
        private IObserver<BaggageInfo> _observer;
        internal Unsubscriber(List<IObserver<BaggageInfo>> observers, IObserver<BaggageInfo> observer)
        {
            this._observers = observers;
            this._observer = observer;
        }

        public void Dispose()
        {
            if (_observers.Contains(_observer))
                _observers.Remove(_observer);
        }
    }

    public class ArrivalsMonitor : IObserver<BaggageInfo>
    {
        private string name;
        private List<string> flightInfos = new List<string>();
        private IDisposable cancellation;
        private string fmt = "{0,-20}{1,5}{2,3}";

        public ArrivalsMonitor(string name)
        {
            if (String.IsNullOrEmpty(name))
                throw new ArgumentException("The observer ust be assigned a name");

            this.name = name;
        }

        public virtual void Subscribe(BaggageHandler provider)
        {
            cancellation = provider.Subscribe(this);
        }

        public virtual void Unsubscribe()
        {
            cancellation.Dispose();
            flightInfos.Clear();
        }

        public virtual void OnCompleted()
        {
            flightInfos.Clear();
        }

        //--No implementation needed: Method is not called by the BaggageHandler class.
        public virtual void OnError(Exception ex)
        {
            //--No Implementation.
        }

        //--Update Information
        public virtual void OnNext(BaggageInfo info)
        {
            bool update = false;
            // Flight has unloaded its baggage; remove from the monitor.
            if(info.Carousel == 0)
            {
                var flightsToRemove = new List<string>();
                string fli
            }
        }
    }
}
