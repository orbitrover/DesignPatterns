﻿//using System;
//using System.Collections.Generic;
//using System.Text;
//using System.Threading;
//using System.Threading.Tasks;

//namespace Core.PacticeConsoleApp
//{
//    public sealed class Channel<T>
//    {
//        public void Write(T value);
//        public ValueTask<T> ReadAsync(CancellationToken cancellationToken = default);
//    }

//    public abstract class ChannelWriter<T>
//    {
//        public abstract bool TryWrite(T item);
//        public virtual ValueTask WriteAsync(T item, CancellationToken cancellationToken = default);
//        public abstract ValueTask<bool> WaitToWriteAsync(CancellationToken cancellationToken = default);
//        public void Complete(Exception error);
//        public virtual bool TryComplete(Exception error);
//    }
//    public abstract class ChannelReader<T>
//    {
//        public abstract bool TryRead(out T item);
//        public virtual ValueTask<T> ReadAsync(CancellationToken cancellationToken = default)
//        public abstract ValueTask<bool> WaitToReadAsync(CancellationToken cancellationToken = default);
//        public virtual IAsyncEnumerable<T> ReadAllAsync([EnumeratorCancellation] CancellationToken cancellationToken = default);
//        public virtual Task Completion { get; }
//    }

//    public enum BoundedChannelFullMode
//    {
//        Wait,
//        DropNewest,
//        DropOldest,
//        DropWrite
//    }
//}
